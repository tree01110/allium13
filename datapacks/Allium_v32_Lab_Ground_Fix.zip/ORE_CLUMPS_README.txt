Deep Ocean Ore Clumps - v13
===========================
Normal clumps: 5 irregular variants per ore, up to ~5x5x7.
Rare giant clumps: 1 oversized variant per ore, mineral mass ~7x7 footprint and 15 blocks tall, with a wider 9x9 magma skirt.
Normal structure-set placement: spacing 10 chunks, separation 5 chunks.
Rare giant placement: spacing 48 chunks, separation 24 chunks.
All clumps project to OCEAN_FLOOR_WG and use the offshore/deep ocean biome tag.
Ordinary shallow ocean biomes are intentionally excluded because they can border beaches.

zinc: unify:raw_zinc_block + unify:deepslate_zinc_ore
lead: unify:raw_lead_block + unify:deepslate_lead_ore
gold: minecraft:raw_gold_block + minecraft:gold_ore
platinum: unify:raw_platinum_block + unify:deepslate_platinum_ore
uranium: unify:raw_uranium_block + unify:deepslate_uranium_ore
