ALLIUM OCEAN CARGO BARRELS v1
================================

Install the ZIP directly in world/datapacks/.

NORMAL OCEANS (weighted 40/35/25)
- Drifting Cargo
- Fishing Supplies
- Waterlogged Provisions
Placement: spacing 14 chunks, separation 8.

DEEP OCEANS (weighted 60/30/10)
- Merchant Cargo
- Fishing Vessel Cargo
- Lost Treasure (guaranteed Heart of the Sea)
Placement: spacing 32 chunks, separation 20.

Barrels project to OCEAN_FLOOR_WG and have custom inventory titles.
Changes only affect newly generated chunks.

Locate commands:
/locate structure allium_ocean_cargo:drifting_cargo
/locate structure allium_ocean_cargo:merchant_cargo
/locate structure allium_ocean_cargo:lost_treasure

Required item namespaces used in loot:
create, create_integrated_farming, sealife, simulated, unify, extendedae, create_better_motors
